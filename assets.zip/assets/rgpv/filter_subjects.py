#!/usr/bin/env python3

import os
import re

# Files
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FILTER_FILE = os.path.join(BASE_DIR, "subject_filter.txt")

# Read allowed subject IDs
try:
    with open(FILTER_FILE, "r", encoding="utf-8") as f:
        allowed_subjects = {
            line.strip()
            for line in f
            if line.strip() and not line.strip().startswith("#")
        }
except FileNotFoundError:
    print(f"Error: {FILTER_FILE} not found.")
    exit(1)

# Regex to extract subject id
subject_pattern = re.compile(r'<subject\b[^>]*\bid="([^"]+)"')

modified_files = 0
commented_subjects = 0

# Traverse all folders
for root, _, files in os.walk(BASE_DIR):
    if "subjects.xml" not in files:
        continue

    xml_file = os.path.join(root, "subjects.xml")

    with open(xml_file, "r", encoding="utf-8") as f:
        lines = f.readlines()

    new_lines = []
    changed = False

    for line in lines:
        stripped = line.lstrip()

        # Skip already commented lines
        if stripped.startswith("<!--"):
            new_lines.append(line)
            continue

        match = subject_pattern.search(line)

        if match:
            subject_id = match.group(1)

            if subject_id not in allowed_subjects:
                indent = line[:len(line) - len(line.lstrip())]
                commented_line = (
                    f"{indent}<!-- {line.strip()} -->\n"
                )
                new_lines.append(commented_line)
                commented_subjects += 1
                changed = True
            else:
                new_lines.append(line)
        else:
            new_lines.append(line)

    if changed:
        with open(xml_file, "w", encoding="utf-8") as f:
            f.writelines(new_lines)
        modified_files += 1
        print(f"Modified: {xml_file}")

print("\nCompleted.")
print(f"Modified files : {modified_files}")
print(f"Commented subjects : {commented_subjects}")
print(f"Allowed subjects : {len(allowed_subjects)}")